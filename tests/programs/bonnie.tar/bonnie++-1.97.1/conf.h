/* conf.h.  Generated from conf.h.in by configure.  */
#ifndef CONF_H
#define CONF_H

/* #undef HAVE_ALGO_H */
/* #undef HAVE_ALGO */
#define HAVE_ALGORITHM 1
/* #undef HAVE_MIN_MAX */

#endif
